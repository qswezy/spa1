import AbstractView from "./AbstractView.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("Dashboard");
    }

    async getHtml() {
        return `
            <h1>Anasayfaya Hoşgeldiniz</h1>
            <p>
                
            </p>
            <p>
                <a href="/posts" data-link>Duyuruları Göster</a>.
            </p>
        `;
    }
}