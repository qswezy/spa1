import AbstractView from "./AbstractView.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("Posts");
    }

    async getHtml() {
        return `
            <center>
            <h1>Admin Panel</h1>
            <form>
            <input class= "BaslikEkle"   placeholder="Başlık Giriniz"><br>
            <textarea class= "MetinGiriniz" placeholder="Metin Giriniz"></textarea><br>
            <input type="Submit">
            <input type="Reset">
            </form>
            </center>
        `;
    }
}