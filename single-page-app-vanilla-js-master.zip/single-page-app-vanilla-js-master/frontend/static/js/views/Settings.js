import AbstractView from "./AbstractView.js";

export default class extends AbstractView {
    constructor(params) {
        super(params);
        this.setTitle("Settings");
    }

    async getHtml() {
        return `
            <h1>İletişim Bilgileri</h1>
            <p style="color:White;">Çakmak mahallesi yenigün sokak.</p>
            <p style="color:White;">555 444 33 22</p>
            <p style="color:White;">E-posta : qSwezy@hotmail.com</p>
        `;
    }
}